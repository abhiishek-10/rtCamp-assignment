wp.blocks.registerBlockType('post-slideshow-block/post-slideshow', {
    title: 'Post SlideShow Custom Block',
    icons: 'hammer',
    category: 'design',

    edit: function (props) {
        return wp.element.createElement(
            "div",
            {
                dangerouslySetInnerHTML: {
                    __html: inputToFetch()
                }
            }

        );
    },
    save: function (props) {
        return wp.element.createElement(
            "div",
            {
                dangerouslySetInnerHTML: {
                    __html: fetchData()

                }
            }
        );
    }
})

function inputToFetch() {
    return backendHtml = `
    <input type='text' id='urlInput' placeholder='URL'> 
    <button id='fetch'>Fetch</button> 
    `
}

let postImages = "";

function fetchData() {
    (fetch('https://wptavern.com/wp-json/wp/v2/posts')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            for (let i = 0; i < data.length; i++) {
                postImages += `<a href="${data[i].link}" target="_blank"> <img src="${data[i].episode_featured_image}" alt="${data[i].id}"></a>`
            }
        }), postImages)
    return html = `<div id="my-slider" class="slider"> 
                    <div class="controls">
                        <button type="button" class="prev"><svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_903_6754)">
                        <path d="M25 30L15 20L25 10" stroke="#B3B3B3" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_903_6754">
                        <rect width="40" height="40" fill="white" transform="matrix(-1.19249e-08 -1 -1 1.19249e-08 40 40)"/>
                        </clipPath>
                        </defs>
                        </svg>
                        </button>
                        <button type="button" class="next"><svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_903_6745)">
                        <path d="M15 30L25 20L15 10" stroke="#B3B3B3" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                        <defs>
                        <clipPath id="clip0_903_6745">
                        <rect width="40" height="40" fill="white" transform="translate(0 40) rotate(-90)"/>
                        </clipPath>
                        </defs>
                        </svg>
                        </button>
                    </div> 
                    <div class="slides-wrapper">
                        <div class="slides">
                          ${postImages}
                        </div>
                    </div>
                </div>`;
}




// async function fetchData() {
//     try {
//         // Perform your API call here
//         // For example, using fetch:
//         const response = await fetch('https://wptavern.com/wp-json/wp/v2/posts');
//         const data = await response.json();
//         return data[0].episode_featured_image;
//     } catch (error) {
//         throw error;
//     }
// }

// async function getData() {
//     try {
//         const data = await fetchData();
//         // Process the retrieved data if needed
//         return data;
//     } catch (error) {
//         throw error;
//     }
// }
// // Usage
// async function mainData() {
//     try {
//         const data = await getData();
//         console.log(data); // Use the retrieved data here
//     } catch (error) {
//         console.error(error); // Handle any errors
//     }
// }


// function makeGetRequest(path) {
//     return new Promise(function (resolve, reject) {
//         axios.get(path).then(
//             (response) => {
//                 var result = response.data;
//                 console.log('Processing Request');
//                 resolve(result);
//             },
//             (error) => {
//                 reject(error);
//             }
//         );
//     });
// }
// async function main() {
//     var response = await makeGetRequest('https://wptavern.com/wp-json/wp/v2/posts');
//     console.log(response);
//     for (let i = 0; i < response.length; i++) {
//         postImages += `<img src="${response[i].episode_featured_image
//             } " alt="">`
//         // imageSrc.push(response[i].episode_featured_image)
//     }
//     console.log(postImages);
//     return postImages;
// }
